Project Name - ProjectBuild

Technologies Used
.NET Core 
ASP.NET Core MVC
JSON for data storage

Project Structure
ProjectCompilerController: Controller with endpoints for saving data and retrieving build orders.
ProjectDependencyInput: Model representing the input structure (projects and dependencies).
Dependency: Model representing the dependency pairs between projects.

Endpoints

Method	Endpoint	Description
POST	/insert		Save projects and dependencies to a file.
GET	/list		Retrieve all valid build orders.

Testing Endpoints
1. POST /insert
{
  "projects": ["p1", "p2", "p3", "p4"],
  "dependencies": [
    { "item1": "p1", "item2": "p2" },
    { "item1": "p1", "item2": "p3" },
    { "item1": "p3", "item2": "p4" }
  ]
}

2. GET /list

[
  ["p2", "p4", "p3", "p1"],
  ["p4", "p2", "p3", "p1"]
]

Logging : The project uses ILogger to log errors during API operations.

launchSettings.json - Changed the path from previous https://localhost:3001

https://localhost:3001/list
https://localhost:3001/projectcompiler/list

Note : Other process is not using port 3001.

