using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;

namespace ProjectBuild.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ProjectCompilerController : ControllerBase
    {
        private readonly ILogger<ProjectCompilerController> _logger;
        private const string FilePath = "projects.json";

        public ProjectCompilerController(ILogger<ProjectCompilerController> logger)
        {
            _logger = logger;
        }

        // POST method to save projects and dependencies to a file
        [HttpPost(Name = "InsertProjects")]
        public IActionResult Post([FromBody] ProjectDependencyInput input)
        {
            try
            {
                // Serialize the input data to JSON and save it to a file
                var jsonData = JsonSerializer.Serialize(input, new JsonSerializerOptions { WriteIndented = true });
                System.IO.File.WriteAllText(FilePath, jsonData);
                return Ok("Projects and dependencies saved to file.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error saving projects and dependencies to file.");
                return StatusCode(500, "An error occurred while saving the data.");
            }
        }

        // GET method to retrieve the build order by reading from the file
        [HttpGet("list")]
        public IActionResult Get()
        {
            try
            {
                // Read and deserialize the file content
                if (!System.IO.File.Exists(FilePath))
                {
                    return NotFound("Project data file not found.");
                }

                var jsonData = System.IO.File.ReadAllText(FilePath);
                var input = JsonSerializer.Deserialize<ProjectDependencyInput>(jsonData);

                var buildOrder = GetBuildOrder(input.Projects, input.Dependencies);
                return Ok(buildOrder);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error generating build order");
                return BadRequest("Invalid project dependencies or an error occurred.");
            }
        }

        // Method to generate the build order using topological sort
        // Method to generate the build order using topological sort
        private List<string> GetBuildOrder(List<string> projects, List<Dependency> dependencies)
        {
            var inDegree = new Dictionary<string, int>();
            var adjList = new Dictionary<string, List<string>>();

            // Initialize in-degree and adjacency list for each project
            foreach (var project in projects)
            {
                inDegree[project] = 0;
                adjList[project] = new List<string>();
            }

            // Adjust interpretation: dependency means prerequisite
            foreach (var dependency in dependencies)
            {
                var prerequisite = dependency.Item2;
                var dependent = dependency.Item1;

                // prerequisite -> dependent
                adjList[prerequisite].Add(dependent);
                inDegree[dependent]++;
            }

            // Queue for projects with no prerequisites (in-degree = 0)
            var queue = new Queue<string>();
            foreach (var project in inDegree.Keys)
            {
                if (inDegree[project] == 0)
                    queue.Enqueue(project);
            }

            var buildOrder = new List<string>();
            while (queue.Count > 0)
            {
                var currentProject = queue.Dequeue();
                buildOrder.Add(currentProject);

                // Reduce the in-degree of dependents
                foreach (var dependentProject in adjList[currentProject])
                {
                    inDegree[dependentProject]--;

                    // If in-degree becomes zero, add to queue
                    if (inDegree[dependentProject] == 0)
                        queue.Enqueue(dependentProject);
                }
            }

            // Validate that we could resolve all projects (no cycles)
            if (buildOrder.Count == projects.Count)
            {
                return buildOrder;
            }
            else
            {
                throw new InvalidOperationException("No valid build order exists due to a cycle in dependencies.");
            }
        }

    }

    // Model to accept input
    public class ProjectDependencyInput
    {
        public List<string> Projects { get; set; }
        public List<Dependency> Dependencies { get; set; }
    }

    // Dependency model to represent each dependency as a tuple
    public class Dependency
    {
        public string Item1 { get; set; } // The project that depends on another project
        public string Item2 { get; set; } // The dependency project
    }
}
